"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"

const competenciasData = [
  {
    id: "autoconhecimento",
    nome: "Autoconhecimento",
    descricao: "Capacidade de reconhecer e compreender as próprias emoções, valores, forças e limitações.",
    rubricas: [
      "Não demonstra autoconhecimento",
      "Demonstra pouco autoconhecimento",
      "Demonstra autoconhecimento moderado",
      "Demonstra bom autoconhecimento",
      "Demonstra excelente autoconhecimento",
    ],
  },
  {
    id: "autocontrole",
    nome: "Autocontrole",
    descricao: "Habilidade de gerenciar as próprias emoções e comportamentos de forma eficaz.",
    rubricas: [
      "Não demonstra autocontrole",
      "Demonstra pouco autocontrole",
      "Demonstra autocontrole moderado",
      "Demonstra bom autocontrole",
      "Demonstra excelente autocontrole",
    ],
  },
  {
    id: "empatia",
    nome: "Empatia",
    descricao: "Capacidade de compreender e compartilhar os sentimentos dos outros.",
    rubricas: [
      "Não demonstra empatia",
      "Demonstra pouca empatia",
      "Demonstra empatia moderada",
      "Demonstra boa empatia",
      "Demonstra excelente empatia",
    ],
  },
  {
    id: "comunicacao",
    nome: "Comunicação",
    descricao: "Habilidade de expressar ideias de forma clara e eficaz, tanto verbalmente quanto por escrito.",
    rubricas: [
      "Comunicação muito deficiente",
      "Comunicação deficiente",
      "Comunicação adequada",
      "Boa comunicação",
      "Excelente comunicação",
    ],
  },
  {
    id: "lideranca",
    nome: "Liderança",
    descricao: "Capacidade de influenciar, motivar e guiar outros em direção a objetivos comuns.",
    rubricas: [
      "Não demonstra liderança",
      "Demonstra pouca liderança",
      "Demonstra liderança moderada",
      "Demonstra boa liderança",
      "Demonstra excelente liderança",
    ],
  },
  {
    id: "criatividade",
    nome: "Criatividade",
    descricao: "Habilidade de gerar ideias originais e encontrar soluções inovadoras para problemas.",
    rubricas: [
      "Não demonstra criatividade",
      "Demonstra pouca criatividade",
      "Demonstra criatividade moderada",
      "Demonstra boa criatividade",
      "Demonstra excelente criatividade",
    ],
  },
]

export default function GerenciarCompetencias() {
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [editingCompetency, setEditingCompetency] = useState(null)
  const [formData, setFormData] = useState({
    nome: "",
    descricao: "",
    rubricas: ["", "", "", "", ""],
  })

  const openAddModal = () => {
    setEditingCompetency(null)
    setFormData({ nome: "", descricao: "", rubricas: ["", "", "", "", ""] })
    setIsModalOpen(true)
  }

  const editCompetency = (competency) => {
    setEditingCompetency(competency)
    setFormData({
      nome: competency.nome,
      descricao: competency.descricao,
      rubricas: [...competency.rubricas],
    })
    setIsModalOpen(true)
  }

  const deleteCompetency = (competencyId) => {
    if (confirm("Tem certeza que deseja excluir esta competência?")) {
      alert("Competência excluída com sucesso!")
    }
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    alert("Competência salva com sucesso!")
    setIsModalOpen(false)
  }

  const updateRubrica = (index, value) => {
    const newRubricas = [...formData.rubricas]
    newRubricas[index] = value
    setFormData({ ...formData, rubricas: newRubricas })
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Sidebar */}
      <aside className="fixed left-0 top-0 h-full w-64 bg-white shadow-lg border-r border-gray-200 z-40">
        <div className="p-6 border-b border-gray-200">
          <div className="flex flex-col">
            <h2 className="text-xl font-bold text-gray-900">GPTICS</h2>
            <span className="text-sm text-gray-600">Sistema de Competências</span>
          </div>
        </div>

        <nav className="p-4 space-y-2">
          <a
            href="/dashboard-coordenador"
            className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <span className="text-lg">📊</span>
            Dashboard
          </a>
          <a
            href="/relatorios-agregados"
            className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <span className="text-lg">📈</span>
            Relatórios Agregados
          </a>
          <a
            href="/gerenciar-competencias"
            className="flex items-center gap-3 px-4 py-3 text-blue-600 bg-blue-50 rounded-lg font-medium"
          >
            <span className="text-lg">⚙️</span>
            Gerenciar Competências
          </a>
          <a
            href="/"
            className="flex items-center gap-3 px-4 py-3 text-red-600 hover:bg-red-50 rounded-lg transition-colors mt-8"
          >
            <span className="text-lg">🚪</span>
            Sair
          </a>
        </nav>
      </aside>

      {/* Main Content */}
      <main className="ml-64 p-6">
        {/* Header */}
        <header className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Gerenciar Competências</h1>
          <div className="text-right">
            <div className="font-semibold text-gray-900">Dr. Maria Silva</div>
            <div className="text-sm text-gray-600">Coordenadora Acadêmica</div>
          </div>
        </header>

        {/* Actions Section */}
        <section className="mb-8">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold text-gray-900">Competências Cadastradas</h2>
            <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
              <DialogTrigger asChild>
                <Button onClick={openAddModal}>➕ Adicionar Competência</Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>{editingCompetency ? "Editar Competência" : "Adicionar Nova Competência"}</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700">Nome da Competência</label>
                    <Input
                      value={formData.nome}
                      onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700">Descrição</label>
                    <Textarea
                      value={formData.descricao}
                      onChange={(e) => setFormData({ ...formData, descricao: e.target.value })}
                      rows={3}
                      required
                    />
                  </div>

                  <div className="space-y-4">
                    <label className="text-sm font-medium text-gray-700">Rubricas de Avaliação</label>
                    {formData.rubricas.map((rubrica, index) => (
                      <div key={index} className="flex items-center gap-3">
                        <label className="text-sm font-medium text-gray-600 w-16">Nível {index + 1}:</label>
                        <Input
                          value={rubrica}
                          onChange={(e) => updateRubrica(index, e.target.value)}
                          placeholder={`Descrição para nível ${index + 1}`}
                          className="flex-1"
                        />
                      </div>
                    ))}
                  </div>

                  <div className="flex justify-end gap-3 pt-4">
                    <Button type="button" variant="outline" onClick={() => setIsModalOpen(false)}>
                      Cancelar
                    </Button>
                    <Button type="submit">Salvar Competência</Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </section>

        {/* Competencies List */}
        <section>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {competenciasData.map((competencia) => (
              <Card key={competencia.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <CardTitle className="text-lg">{competencia.nome}</CardTitle>
                    <div className="flex gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => editCompetency(competencia)}
                        className="hover:bg-blue-50"
                      >
                        ✏️
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => deleteCompetency(competencia.id)}
                        className="hover:bg-red-50"
                      >
                        🗑️
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4 leading-relaxed">{competencia.descricao}</p>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Rubricas de Avaliação:</h4>
                    <ul className="space-y-1">
                      {competencia.rubricas.map((rubrica, index) => (
                        <li key={index} className="text-sm text-gray-600">
                          <strong>{index + 1}:</strong> {rubrica}
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      </main>
    </div>
  )
}
