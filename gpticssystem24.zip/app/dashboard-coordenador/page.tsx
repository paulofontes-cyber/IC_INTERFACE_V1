"use client"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from "recharts"

const courseData = [
  { name: "Engenharia", media: 4.5 },
  { name: "Medicina", media: 4.3 },
  { name: "Direito", media: 4.1 },
  { name: "Administração", media: 4.2 },
  { name: "Psicologia", media: 4.6 },
  { name: "Educação", media: 4.4 },
]

const engagementData = [
  { month: "Jan", alunos: 2400, professores: 120 },
  { month: "Fev", alunos: 2500, professores: 125 },
  { month: "Mar", alunos: 2300, professores: 118 },
  { month: "Abr", alunos: 2600, professores: 130 },
  { month: "Mai", alunos: 2700, professores: 135 },
  { month: "Jun", alunos: 2847, professores: 142 },
]

export default function DashboardCoordenador() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Sidebar */}
      <aside className="fixed left-0 top-0 h-full w-64 bg-white shadow-lg border-r border-gray-200 z-40">
        <div className="p-6 border-b border-gray-200">
          <div className="flex flex-col">
            <h2 className="text-xl font-bold text-gray-900">GPTICS</h2>
            <span className="text-sm text-gray-600">Sistema de Competências</span>
          </div>
        </div>

        <nav className="p-4 space-y-2">
          <a
            href="/dashboard-coordenador"
            className="flex items-center gap-3 px-4 py-3 text-blue-600 bg-blue-50 rounded-lg font-medium"
          >
            <span className="text-lg">📊</span>
            Dashboard
          </a>
          <a
            href="/relatorios-agregados"
            className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <span className="text-lg">📈</span>
            Relatórios Agregados
          </a>
          <a
            href="/gerenciar-competencias"
            className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <span className="text-lg">⚙️</span>
            Gerenciar Competências
          </a>
          <a
            href="/"
            className="flex items-center gap-3 px-4 py-3 text-red-600 hover:bg-red-50 rounded-lg transition-colors mt-8"
          >
            <span className="text-lg">🚪</span>
            Sair
          </a>
        </nav>
      </aside>

      {/* Main Content */}
      <main className="ml-64 p-6">
        {/* Header */}
        <header className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Dashboard Estratégico</h1>
          <div className="text-right">
            <div className="font-semibold text-gray-900">Dr. Maria Silva</div>
            <div className="text-sm text-gray-600">Coordenadora Acadêmica</div>
          </div>
        </header>

        {/* KPIs Section */}
        <section className="mb-8">
          <h2 className="text-xl font-bold text-gray-900 mb-6">Indicadores Principais</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center text-2xl">👥</div>
                  <div>
                    <h3 className="text-sm font-medium text-gray-600">Total de Alunos</h3>
                    <div className="text-2xl font-bold text-gray-900">2,847</div>
                    <div className="text-sm text-green-600">+5.2% vs mês anterior</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center text-2xl">📚</div>
                  <div>
                    <h3 className="text-sm font-medium text-gray-600">Cursos Ativos</h3>
                    <div className="text-2xl font-bold text-gray-900">24</div>
                    <div className="text-sm text-gray-600">Sem alteração</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center text-2xl">✅</div>
                  <div>
                    <h3 className="text-sm font-medium text-gray-600">Taxa de Avaliação</h3>
                    <div className="text-2xl font-bold text-gray-900">87.3%</div>
                    <div className="text-sm text-green-600">+2.1% vs mês anterior</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center text-2xl">📊</div>
                  <div>
                    <h3 className="text-sm font-medium text-gray-600">Média Geral</h3>
                    <div className="text-2xl font-bold text-gray-900">4.2</div>
                    <div className="text-sm text-green-600">+0.3 vs semestre anterior</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Charts Section */}
        <section className="mb-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Desempenho por Curso</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={courseData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis domain={[0, 5]} />
                    <Tooltip />
                    <Bar dataKey="media" fill="#3b82f6" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Engajamento Mensal</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={engagementData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Line type="monotone" dataKey="alunos" stroke="#10b981" strokeWidth={2} />
                    <Line type="monotone" dataKey="professores" stroke="#f59e0b" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Management Tools */}
        <section className="mb-8">
          <h2 className="text-xl font-bold text-gray-900 mb-6">Ferramentas de Gestão</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="text-4xl mb-4">👨‍🏫</div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Gestão de Professores</h3>
                <p className="text-gray-600 mb-4">Gerenciar professores, turmas e permissões</p>
                <Button onClick={() => alert("Funcionalidade em desenvolvimento")}>Acessar</Button>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="text-4xl mb-4">👨‍🎓</div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Gestão de Alunos</h3>
                <p className="text-gray-600 mb-4">Visualizar e gerenciar dados dos alunos</p>
                <Button onClick={() => alert("Funcionalidade em desenvolvimento")}>Acessar</Button>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="text-4xl mb-4">📋</div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Configurações do Sistema</h3>
                <p className="text-gray-600 mb-4">Configurar parâmetros e preferências</p>
                <Button onClick={() => alert("Funcionalidade em desenvolvimento")}>Acessar</Button>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Quick Reports */}
        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-6">Relatórios Rápidos</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <h4 className="text-lg font-semibold text-gray-900 mb-2">Relatório Mensal de Competências</h4>
                <p className="text-gray-600 mb-4">Análise consolidada do desenvolvimento de competências</p>
                <Button variant="outline" asChild>
                  <a href="/relatorios-agregados">Gerar Relatório</a>
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <h4 className="text-lg font-semibold text-gray-900 mb-2">Relatório de Engajamento</h4>
                <p className="text-gray-600 mb-4">Métricas de participação de alunos e professores</p>
                <Button variant="outline" asChild>
                  <a href="/relatorios-agregados">Gerar Relatório</a>
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <h4 className="text-lg font-semibold text-gray-900 mb-2">Relatório Comparativo de Cursos</h4>
                <p className="text-gray-600 mb-4">Comparação de desempenho entre diferentes cursos</p>
                <Button variant="outline" asChild>
                  <a href="/relatorios-agregados">Gerar Relatório</a>
                </Button>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>
    </div>
  )
}
