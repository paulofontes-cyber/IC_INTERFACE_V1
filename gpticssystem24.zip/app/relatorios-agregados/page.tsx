"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from "recharts"

const competencyData = [
  { competencia: "Autoconhecimento", media: 4.2 },
  { competencia: "Autocontrole", media: 4.1 },
  { competencia: "Empatia", media: 4.3 },
  { competencia: "Comunicação", media: 4.5 },
  { competencia: "Liderança", media: 4.0 },
  { competencia: "Criatividade", media: 4.2 },
]

const temporalData = [
  { periodo: "2022.2", media: 3.8 },
  { periodo: "2023.1", media: 4.0 },
  { periodo: "2023.2", media: 4.1 },
  { periodo: "2024.1", media: 4.28 },
]

const tableData = [
  {
    curso: "Engenharia",
    periodo: "2024.1",
    alunos: 342,
    media: 4.5,
    autoconhecimento: 4.3,
    autocontrole: 4.6,
    empatia: 4.2,
    comunicacao: 4.7,
    lideranca: 4.4,
  },
  {
    curso: "Medicina",
    periodo: "2024.1",
    alunos: 198,
    media: 4.3,
    autoconhecimento: 4.5,
    autocontrole: 4.1,
    empatia: 4.6,
    comunicacao: 4.2,
    lideranca: 4.1,
  },
  {
    curso: "Direito",
    periodo: "2024.1",
    alunos: 287,
    media: 4.1,
    autoconhecimento: 4.0,
    autocontrole: 4.2,
    empatia: 4.3,
    comunicacao: 4.4,
    lideranca: 3.8,
  },
  {
    curso: "Administração",
    periodo: "2024.1",
    alunos: 456,
    media: 4.2,
    autoconhecimento: 4.1,
    autocontrole: 4.0,
    empatia: 4.2,
    comunicacao: 4.5,
    lideranca: 4.3,
  },
]

export default function RelatoriosAgregados() {
  const [curso, setCurso] = useState("all")
  const [periodo, setPeriodo] = useState("2024-1")
  const [competencia, setCompetencia] = useState("all")

  const generateReport = () => {
    alert("Relatório gerado com base nos filtros selecionados!")
  }

  const exportCSV = () => {
    alert("Exportando dados em formato CSV...")
  }

  const exportPDF = () => {
    alert("Exportando relatório em formato PDF...")
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Sidebar */}
      <aside className="fixed left-0 top-0 h-full w-64 bg-white shadow-lg border-r border-gray-200 z-40">
        <div className="p-6 border-b border-gray-200">
          <div className="flex flex-col">
            <h2 className="text-xl font-bold text-gray-900">GPTICS</h2>
            <span className="text-sm text-gray-600">Sistema de Competências</span>
          </div>
        </div>

        <nav className="p-4 space-y-2">
          <a
            href="/dashboard-coordenador"
            className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <span className="text-lg">📊</span>
            Dashboard
          </a>
          <a
            href="/relatorios-agregados"
            className="flex items-center gap-3 px-4 py-3 text-blue-600 bg-blue-50 rounded-lg font-medium"
          >
            <span className="text-lg">📈</span>
            Relatórios Agregados
          </a>
          <a
            href="/gerenciar-competencias"
            className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <span className="text-lg">⚙️</span>
            Gerenciar Competências
          </a>
          <a
            href="/"
            className="flex items-center gap-3 px-4 py-3 text-red-600 hover:bg-red-50 rounded-lg transition-colors mt-8"
          >
            <span className="text-lg">🚪</span>
            Sair
          </a>
        </nav>
      </aside>

      {/* Main Content */}
      <main className="ml-64 p-6">
        {/* Header */}
        <header className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Relatórios Agregados</h1>
          <div className="text-right">
            <div className="font-semibold text-gray-900">Dr. Maria Silva</div>
            <div className="text-sm text-gray-600">Coordenadora Acadêmica</div>
          </div>
        </header>

        {/* Filters Section */}
        <section className="mb-8">
          <h2 className="text-xl font-bold text-gray-900 mb-6">Filtros de Relatório</h2>
          <Card>
            <CardContent className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">Curso</label>
                  <Select value={curso} onValueChange={setCurso}>
                    <SelectTrigger>
                      <SelectValue placeholder="Todos os Cursos" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos os Cursos</SelectItem>
                      <SelectItem value="engenharia">Engenharia</SelectItem>
                      <SelectItem value="medicina">Medicina</SelectItem>
                      <SelectItem value="direito">Direito</SelectItem>
                      <SelectItem value="administracao">Administração</SelectItem>
                      <SelectItem value="psicologia">Psicologia</SelectItem>
                      <SelectItem value="educacao">Educação</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">Período</label>
                  <Select value={periodo} onValueChange={setPeriodo}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="2024-1">2024.1</SelectItem>
                      <SelectItem value="2023-2">2023.2</SelectItem>
                      <SelectItem value="2023-1">2023.1</SelectItem>
                      <SelectItem value="2022-2">2022.2</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">Competência</label>
                  <Select value={competencia} onValueChange={setCompetencia}>
                    <SelectTrigger>
                      <SelectValue placeholder="Todas as Competências" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todas as Competências</SelectItem>
                      <SelectItem value="autoconhecimento">Autoconhecimento</SelectItem>
                      <SelectItem value="autocontrole">Autocontrole</SelectItem>
                      <SelectItem value="empatia">Empatia</SelectItem>
                      <SelectItem value="comunicacao">Comunicação</SelectItem>
                      <SelectItem value="lideranca">Liderança</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button onClick={generateReport} className="w-full">
                  Gerar Relatório
                </Button>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Report Results */}
        <section className="mb-8">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Resultados do Relatório</CardTitle>
                <div className="flex gap-2">
                  <Button variant="outline" onClick={exportCSV}>
                    📊 Exportar CSV
                  </Button>
                  <Button variant="outline" onClick={exportPDF}>
                    📄 Exportar PDF
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {/* Charts */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Distribuição por Competência</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <RadarChart data={competencyData}>
                        <PolarGrid />
                        <PolarAngleAxis dataKey="competencia" />
                        <PolarRadiusAxis domain={[0, 5]} />
                        <Radar name="Média" dataKey="media" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.2} />
                      </RadarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Evolução Temporal</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <LineChart data={temporalData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="periodo" />
                        <YAxis domain={[0, 5]} />
                        <Tooltip />
                        <Line type="monotone" dataKey="media" stroke="#3b82f6" strokeWidth={2} />
                      </LineChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </div>

              {/* Data Table */}
              <Card className="mb-8">
                <CardHeader>
                  <CardTitle className="text-lg">Dados Detalhados</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b bg-gray-50">
                          <th className="text-left p-3 font-medium">Curso</th>
                          <th className="text-left p-3 font-medium">Período</th>
                          <th className="text-left p-3 font-medium">Alunos Avaliados</th>
                          <th className="text-left p-3 font-medium">Média Geral</th>
                          <th className="text-left p-3 font-medium">Autoconhecimento</th>
                          <th className="text-left p-3 font-medium">Autocontrole</th>
                          <th className="text-left p-3 font-medium">Empatia</th>
                          <th className="text-left p-3 font-medium">Comunicação</th>
                          <th className="text-left p-3 font-medium">Liderança</th>
                        </tr>
                      </thead>
                      <tbody>
                        {tableData.map((row, index) => (
                          <tr key={index} className="border-b hover:bg-gray-50">
                            <td className="p-3">{row.curso}</td>
                            <td className="p-3">{row.periodo}</td>
                            <td className="p-3">{row.alunos}</td>
                            <td className="p-3 font-medium">{row.media}</td>
                            <td className="p-3">{row.autoconhecimento}</td>
                            <td className="p-3">{row.autocontrole}</td>
                            <td className="p-3">{row.empatia}</td>
                            <td className="p-3">{row.comunicacao}</td>
                            <td className="p-3">{row.lideranca}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>

              {/* Summary Statistics */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Estatísticas Resumo</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="bg-blue-50 p-4 rounded-lg text-center">
                      <div className="text-sm text-gray-600 mb-1">Total de Alunos Avaliados</div>
                      <div className="text-2xl font-bold text-gray-900">1,283</div>
                    </div>
                    <div className="bg-blue-50 p-4 rounded-lg text-center">
                      <div className="text-sm text-gray-600 mb-1">Média Geral Institucional</div>
                      <div className="text-2xl font-bold text-gray-900">4.28</div>
                    </div>
                    <div className="bg-green-50 p-4 rounded-lg text-center">
                      <div className="text-sm text-gray-600 mb-1">Competência com Maior Média</div>
                      <div className="text-lg font-bold text-gray-900">Comunicação (4.45)</div>
                    </div>
                    <div className="bg-orange-50 p-4 rounded-lg text-center">
                      <div className="text-sm text-gray-600 mb-1">Competência com Menor Média</div>
                      <div className="text-lg font-bold text-gray-900">Liderança (4.15)</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </CardContent>
          </Card>
        </section>
      </main>
    </div>
  )
}
